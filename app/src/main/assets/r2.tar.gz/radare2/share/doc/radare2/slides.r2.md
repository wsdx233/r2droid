# Welcome to radare2
--label:title

This is an introductory course to radare2

`?E Welcome to r2land`

`o;pd 4`

--gotokey:i:insert
Press 'n' for next slide (or the spacebar)
Press 'p' to see clippy moving


--pancake

# Contents

We will cover the following topics:

* What is radare2?
* How to install it
* Basic shell usage
* Scripting examples

# Insertion
--label:insert

To insert stuff press : to enter shell and then
use the 'w' command to write a string.

`?ef w hello world`

# Questions

Please send me an email

In this course we will see:

--pancake
