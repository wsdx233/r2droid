# IDA

You can find conversion scripts to work between radare2 and IDA files (IDC, IDB...) here:

[https://github.com/radareorg/radare2-extras/tree/master/r2ida](https://github.com/radareorg/radare2-extras/tree/master/r2ida)

