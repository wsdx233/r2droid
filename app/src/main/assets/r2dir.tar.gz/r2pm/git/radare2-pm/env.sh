export R2PM_DBDIR="$PWD/db"
