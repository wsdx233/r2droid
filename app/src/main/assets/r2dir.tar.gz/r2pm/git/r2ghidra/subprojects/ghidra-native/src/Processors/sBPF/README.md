# sBPF

The code comes from https://github.com/riptl/ghidra-ebpf.git, modified from eBPF to sBPF.
