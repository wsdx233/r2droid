#ifndef CUSTOM_ASSERT_H
#define CUSTOM_ASSERT_H 1

#define assert(x) if ((x)) {}

#endif
